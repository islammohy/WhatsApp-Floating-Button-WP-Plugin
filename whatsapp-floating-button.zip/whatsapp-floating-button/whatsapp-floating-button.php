<?php
/*
Plugin Name: igy-apps WhatsApp Floating Button
Plugin URI: igy-apps.com
Description: Add a floating WhatsApp button to your website.
Version: 1.0
Author: igy-apps.com
Author URI: igy-apps.com
License: GPL2
*/

function whatsapp_floating_button_enqueue_scripts() {
  wp_enqueue_style( 'whatsapp-floating-button-style', plugin_dir_url( __FILE__ ) . 'style.css' );
  wp_enqueue_script( 'whatsapp-floating-button-script', plugin_dir_url( __FILE__ ) . 'script.js', array( 'jquery' ), '1.0', true );
}
add_action( 'wp_enqueue_scripts', 'whatsapp_floating_button_enqueue_scripts' );

function whatsapp_floating_button_output() {
  $whatsapp_number = get_option( 'whatsapp_number' );
  $sanitized_number = sanitize_text_field( $whatsapp_number );
  $validated_number = preg_replace( '/[^+\d]/', '', $sanitized_number ); // Remove non-digit characters except '+'

  if ( empty( $validated_number ) ) {
    return; // Don't output anything if the number is empty or invalid
  }

  $output = '<div id="whatsapp-floating-button">';
  $output .= '<a href="https://api.whatsapp.com/send?phone=' . urlencode( $validated_number ) . '" target="_blank">';
  $output .= '<img src="' . plugin_dir_url( __FILE__ ) . 'whatsapp-icon.png" alt="WhatsApp">';
  $output .= '</a>';
  $output .= '</div>';

  echo $output;
}

add_action( 'wp_footer', 'whatsapp_floating_button_output' );

function whatsapp_floating_button_admin_menu() {
  add_options_page( 'WhatsApp Floating Button Settings', 'WhatsApp Floating Button', 'manage_options', 'whatsapp-floating-button-settings', 'whatsapp_floating_button_settings_page' );
}
add_action( 'admin_menu', 'whatsapp_floating_button_admin_menu' );

function whatsapp_floating_button_settings_page() {
  if ( ! current_user_can( 'manage_options' ) ) {
    return;
  }

  if ( isset( $_GET['settings-updated'] ) ) {
    add_settings_error( 'whatsapp-floating-button-notices', 'whatsapp-floating-button-message', 'Settings Saved', 'updated' );
  }

  settings_errors( 'whatsapp-floating-button-notices' );
  ?>
  <div class="wrap">
    <h1>WhatsApp Floating Button Settings</h1>
    <form method="post" action="options.php">
      <?php
      settings_fields( 'whatsapp-floating-button-settings' );
      do_settings_sections( 'whatsapp-floating-button-settings' );
      submit_button( 'Save Settings' );
      ?>
    </form>
  </div>
  <?php
}

function whatsapp_floating_button_register_settings() {
  register_setting( 'whatsapp-floating-button-settings', 'whatsapp_number' );
  add_settings_section( 'whatsapp-floating-button-general', 'General Settings', 'whatsapp_floating_button_general_settings_callback', 'whatsapp-floating-button-settings' );
  add_settings_field( 'whatsapp-number', 'WhatsApp Number', 'whatsapp_number_field_callback', 'whatsapp-floating-button-settings', 'whatsapp-floating-button-general' );
}
add_action( 'admin_init', 'whatsapp_floating_button_register_settings' );

function whatsapp_floating_button_general_settings_callback() {
  echo '<p>Configure the settings for the WhatsApp Floating Button.</p>';
}

function whatsapp_number_field_callback() {
  $whatsapp_number = get_option( 'whatsapp_number' );
  echo '<input type="text" name="whatsapp_number" value="' . esc_attr( $whatsapp_number ) . '" />';
}

// Add settings link
function whatsapp_floating_button_settings_link( $links ) {
  $settings_link = '<a href="options-general.php?page=whatsapp-floating-button-settings">Settings</a>';
  array_push( $links, $settings_link );
  return $links;
}
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'whatsapp_floating_button_settings_link' );
